<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class xpack_inv extends Model
{
    protected $table="xpack_invest";
}
